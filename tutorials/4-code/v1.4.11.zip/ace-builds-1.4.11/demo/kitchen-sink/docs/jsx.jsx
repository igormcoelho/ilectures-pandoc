/*EXPECTED
hello world!
*/
class Test {
    static function run() : void {
        // console.log("hello world!");
        log "hello world!";
    }
}